# Windows Update at Startup — Auto-Reboot & Auto-Cleanup

This package installs all available Windows Updates **at every startup**, allows **automatic reboots** when required, and **removes the scheduled task automatically** once the device is fully up-to-date (and no reboot is pending).

## Files

- `Apply-WindowsUpdates.ps1` — main script. Uses **PSWindowsUpdate** if available; will attempt to install it if missing. Logs to `C:\\ProgramData\\WindowsUpdate\\Logs\\`.
- `Register-StartupUpdateTask.ps1` — registers a **SYSTEM** scheduled task that runs at startup with a short randomized delay.
- `Unregister-StartupUpdateTask.ps1` — optional manual cleanup.

## Quick start

1. Copy the folder (or extract the ZIP) to `C:\\Scripts` **or** keep anywhere you like.
2. Open **PowerShell as Administrator**.
3. Register the startup task:
   ```powershell
   cd <folder-you-extracted>
   .\Register-StartupUpdateTask.ps1 -ScriptPath "C:\\Scripts\\Apply-WindowsUpdates.ps1"
   ```
   (If you keep the files in another folder, pass the full path to `Apply-WindowsUpdates.ps1`.)
4. **Restart** your PC. The task runs at boot, installs updates, and reboots automatically if needed. It will run again after each reboot until no updates remain.
5. When the machine is fully updated and no reboot is pending, the script **removes the scheduled task automatically**.

## Behavior & safeguards

- **Auto-reboot**: Enabled. If an update requires a reboot, the script calls `Restart-Computer -Force` (or `-AutoReboot` during installation) and continues next boot.
- **Cooldown**: Prevents tight loops by skipping runs that happened within **30 minutes**. Adjust with `-CooldownMinutes` if needed.
- **Logging**: See `C:\\ProgramData\\WindowsUpdate\\Logs\\WU-*.log` and Event Viewer → *Applications and Services Logs → Microsoft → Windows → WindowsUpdateClient → Operational*.
- **Microsoft Update**: The script enrolls the Microsoft Update catalog (Office/Edge/VS) when possible.

## Manual controls

- Remove the task manually anytime:
  ```powershell
  .\Unregister-StartupUpdateTask.ps1
  ```
- Run the updater ad-hoc (as admin):
  ```powershell
  powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\Scripts\\Apply-WindowsUpdates.ps1"
  ```

## Notes

- On managed devices (GPO/Intune/WSUS), policies may influence which updates are offered and when reboots occur.
- Ensure services `wuauserv`, `bits`, and `UsoSvc` are not disabled.
- Keep at least **10–20 GB** free disk space for feature upgrades.
