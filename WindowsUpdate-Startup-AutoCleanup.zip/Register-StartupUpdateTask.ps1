#requires -RunAsAdministrator
<#!
    Register-StartupUpdateTask.ps1
    Purpose : Registers a Scheduled Task that runs Apply-WindowsUpdates.ps1 at every system startup.
!>
param(
    [string]$ScriptPath = 'C:\Scripts\Apply-WindowsUpdates.ps1',
    [string]$TaskName   = 'Auto Windows Update (Startup)'
)

if (-not (Test-Path (Split-Path $ScriptPath))) {
    New-Item -ItemType Directory -Force -Path (Split-Path $ScriptPath) | Out-Null
}

if (-not (Test-Path $ScriptPath)) {
    Write-Warning "Script not found at $ScriptPath. Place Apply-WindowsUpdates.ps1 there or pass -ScriptPath."
}

$action   = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$ScriptPath`""
$trigger  = New-ScheduledTaskTrigger -AtStartup -RandomDelay (New-TimeSpan -Minutes 5)
$principal= New-ScheduledTaskPrincipal -UserId 'SYSTEM' -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit (New-TimeSpan -Hours 3)

Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force |
    Out-Null

Write-Host "Registered startup task '$TaskName'. It will run at next boot and remove itself once fully up to date." -ForegroundColor Green
