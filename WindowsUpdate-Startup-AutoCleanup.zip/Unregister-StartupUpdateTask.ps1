#requires -RunAsAdministrator
<#!
    Unregister-StartupUpdateTask.ps1
    Purpose : Manual cleanup – removes the startup Scheduled Task if you want to stop automatic runs.
!>
param(
    [string]$TaskName = 'Auto Windows Update (Startup)'
)

try {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "Removed scheduled task '$TaskName'." -ForegroundColor Green
} catch {
    Write-Warning "Failed to remove task '$TaskName': $($_.Exception.Message)"
}
