#requires -RunAsAdministrator
<#!
    Apply-WindowsUpdates.ps1
    Purpose : Install all Windows Updates automatically at each startup and reboot if required.
              Once the device is fully up-to-date and no reboot is pending, removes the startup task.
    Notes   :
      - Uses PSWindowsUpdate if available; will attempt to install it from PSGallery if missing.
      - Logs to C:\ProgramData\WindowsUpdate\Logs\
      - Includes a cooldown (default 30 minutes) so repeated quick reboots don't cause tight loops.
!>

param(
    [int]$CooldownMinutes = 30,
    [string]$TaskName = 'Auto Windows Update (Startup)'
)

$ErrorActionPreference = 'Stop'

# --- Logging & State ---
$LogDir   = Join-Path $env:ProgramData 'WindowsUpdate/Logs'
$StateDir = Join-Path $env:ProgramData 'WindowsUpdate'
$State    = Join-Path $StateDir 'state.json'
New-Item -ItemType Directory -Path $LogDir  -Force | Out-Null
New-Item -ItemType Directory -Path $StateDir -Force | Out-Null
$LogFile  = Join-Path $LogDir ("WU-" + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')

function Write-Log {
    param([string]$Message)
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$ts] $Message"
    $line | Tee-Object -FilePath $LogFile -Append | Out-Null
}

# --- Cooldown guard ---
$now = Get-Date
if (Test-Path $State) {
    try {
        $st = Get-Content $State -Raw | ConvertFrom-Json
        if ($st.LastRun) {
            $last = [datetime]$st.LastRun
            if (($now - $last).TotalMinutes -lt $CooldownMinutes) {
                Write-Log "Skipping due to cooldown ($CooldownMinutes min). LastRun=$last"
                exit 0
            }
        }
    } catch {}
}

# --- Ensure core services ---
foreach ($svc in 'wuauserv','bits','UsoSvc') {
    try {
        Set-Service -Name $svc -StartupType Automatic -ErrorAction Stop
        Start-Service -Name $svc -ErrorAction Stop
        Write-Log "Service $svc is running."
    } catch {
        Write-Log "WARN: Could not start service $svc: $($_.Exception.Message)"
    }
}

# --- Pending reboot check ---
function Test-PendingReboot {
    $paths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired',
        'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager', # check value below
        'HKLM:\SOFTWARE\Microsoft\Updates'
    )
    if (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager') {
        $pfr = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue)
        if ($pfr) { return $true }
    }
    foreach ($p in $paths) { if (Test-Path $p) { if ($p -like '*Session Manager*') { continue } else { return $true } } }
    return $false
}

if (Test-PendingReboot) {
    Write-Log 'Pending reboot detected before update run. Rebooting now to continue update cycle.'
    try { Restart-Computer -Force } catch { }
    exit 0
}

# --- Ensure PSWindowsUpdate ---
function Ensure-PSWindowsUpdate {
    try {
        Import-Module PSWindowsUpdate -ErrorAction Stop
        Write-Log 'PSWindowsUpdate module loaded.'
        return $true
    } catch {
        Write-Log 'PSWindowsUpdate not found. Attempting to install from PSGallery.'
        try {
            $prov = Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue
            if (-not $prov) {
                Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Confirm:$false -ErrorAction Stop | Out-Null
                Write-Log 'NuGet provider installed.'
            }
        } catch { Write-Log "WARN: NuGet provider install failed: $($_.Exception.Message)" }
        try {
            $repo = Get-PSRepository -Name PSGallery -ErrorAction SilentlyContinue
            if (-not $repo) { Register-PSRepository -Name PSGallery -SourceLocation 'https://www.powershellgallery.com/api/v2' -InstallationPolicy Trusted -ErrorAction SilentlyContinue }
            else {
                if ($repo.InstallationPolicy -ne 'Trusted') { Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction SilentlyContinue }
            }
        } catch { Write-Log "WARN: Could not set PSGallery trust: $($_.Exception.Message)" }
        try {
            Install-Module -Name PSWindowsUpdate -Force -AllowClobber -Confirm:$false -ErrorAction Stop
            Import-Module PSWindowsUpdate -ErrorAction Stop
            Write-Log 'PSWindowsUpdate installed and loaded.'
            return $true
        } catch {
            Write-Log "ERROR: Failed to install PSWindowsUpdate: $($_.Exception.Message)"
            return $false
        }
    }
}

if (-not (Ensure-PSWindowsUpdate)) {
    Write-Log 'Falling back to built-in USOClient triggers (reduced control).'
    try {
        & usoClient StartScan   | Out-Null
        & usoClient StartDownload | Out-Null
        & usoClient StartInstall  | Out-Null
        Write-Log 'Triggered scan/download/install via USOClient.'
    } catch {
        Write-Log "ERROR: USOClient trigger failed: $($_.Exception.Message)"
    }
    # Save state and exit; next reboot will try again
    @{ LastRun = (Get-Date) } | ConvertTo-Json | Set-Content -Path $State -Encoding UTF8
    exit 0
}

# --- Microsoft Update catalog (Office/Edge/VS etc.) ---
try { Add-WUServiceManager -MicrosoftUpdate -Confirm:$false | Out-Null; Write-Log 'Microsoft Update catalog enabled.' } catch { Write-Log 'WARN: Could not enable Microsoft Update catalog.' }

# --- Scan for available updates ---
Write-Log 'Starting update scan.'
$available = @()
try {
    $available = @(Get-WindowsUpdate -MicrosoftUpdate -AcceptAll -Verbose 2>&1)
    $available | Tee-Object -FilePath $LogFile -Append | Out-Null
} catch {
    Write-Log "ERROR: Get-WindowsUpdate scan failed: $($_.Exception.Message)"
}

$availableCount = ($available | Where-Object { $_ -isnot [string] }).Count
Write-Log "Available updates detected: $availableCount"

if ($availableCount -gt 0) {
    Write-Log 'Installing updates (AutoReboot enabled if required).'
    try {
        Get-WindowsUpdate -MicrosoftUpdate -AcceptAll -Install -AutoReboot -Verbose 2>&1 |
            Tee-Object -FilePath $LogFile -Append | Out-Null
    } catch {
        Write-Log "ERROR: Installation phase failed: $($_.Exception.Message)"
    }
}

# If we reach here, either no updates were found or install finished without an auto-reboot.
# Re-check pending reboot and rescan to decide cleanup.
if (Test-PendingReboot) {
    Write-Log 'Pending reboot detected after install. Rebooting now.'
    try { Restart-Computer -Force } catch {}
    exit 0
}

# Final rescan; if zero applicable updates remain, remove the scheduled task.
Write-Log 'Final scan to confirm everything is up to date.'
$final = @()
try {
    $final = @(Get-WindowsUpdate -MicrosoftUpdate -AcceptAll -Verbose 2>&1)
    $final | Tee-Object -FilePath $LogFile -Append | Out-Null
} catch {
    Write-Log "WARN: Final scan failed: $($_.Exception.Message)"
}
$finalCount = ($final | Where-Object { $_ -isnot [string] }).Count

if ($finalCount -eq 0 -and -not (Test-PendingReboot)) {
    Write-Log 'System appears fully up to date and no reboot pending. Removing scheduled task.'
    try {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
        Write-Log "Scheduled Task '$TaskName' removed."
    } catch {
        Write-Log "WARN: Failed to remove scheduled task '$TaskName': $($_.Exception.Message)"
    }
} else {
    Write-Log "Updates remaining ($finalCount) or reboot pending; task will run again next startup."
}

# Persist last run time
@{ LastRun = (Get-Date) } | ConvertTo-Json | Set-Content -Path $State -Encoding UTF8
Write-Log 'Run complete.'
